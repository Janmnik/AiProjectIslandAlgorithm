package algortymGenetyczny;

public interface FunkcjaCeluZad1 {
	//zadanie 1
	double func(double x1,double x2);
}
